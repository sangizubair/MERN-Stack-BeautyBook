import mongoose from "mongoose";

const forgetSchema = mongoose.Schema({

    email: {
        type: mongoose.Schema.Types.String,
        ref: "User",
        required: true,
    },

    password: {
        type: String,
        required: true
    },

    date: {
        type: Date,
        default: Date.now
    }
})
export default mongoose.model("forgetpassword", forgetSchema);
