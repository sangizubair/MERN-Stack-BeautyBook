export const DB_NAME="salon";
