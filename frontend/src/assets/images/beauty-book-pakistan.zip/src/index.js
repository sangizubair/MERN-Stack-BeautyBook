
import dotenv from "dotenv"
import { app } from "./app.js"
import Connection from "./dbConfig/connection.js"

dotenv.config({
    path: './env'
})

// response or catch me error ko handle krenge 
Connection().then(() => {
    app.listen(process.env.PORT, () => {
        console.log(`server is running at port : ${process.env.PORT}`);
    })
})
    .catch((err) => {
        console.log("connection failed", err);
    })
