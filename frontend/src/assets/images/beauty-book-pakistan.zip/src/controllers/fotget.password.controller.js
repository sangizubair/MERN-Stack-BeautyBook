import bcrypt from "bcrypt";
import sendEmailForPassword from "../helpers/forget_password_verification";
import { generateOTP, sendEmail } from "../helpers/otpVerification";
import ForgetPasswordModel from "../models/forget.password.model";
import OTPModel from "../models/otp_model";
import AuthModel from "../models/users.models";


const authController = {

  // SEND EMAIL WITH OTP
  sendEmail: async (req, res) => {
    try {
      let emailResult;
      const { userId, email } = req.body;
      const genOtp = generateOTP()
      const doesOTP = await OTPModel.findOne({ userId: userId });
      if (!doesOTP) {
        const newOTP = await OTPModel.create({
          userId: userId,
          otp: genOtp
        })
        emailResult = await sendEmail(userId, email, genOtp)
      } else {
        const deleteOTP = await OTPModel.deleteOne({ userId: userId });
        if (deleteOTP) {
          const newOTP = await OTPModel.create({
            userId: userId,
            otp: genOtp
          })
          emailResult = await sendEmail(userId, email, genOtp)
        }
      }
      if (emailResult.success) {
        res.send({ message: emailResult.message })
      } else {
        res.send({ error: emailResult.message })
      }
    } catch (error) {
      res.status(500).send({ error: "Internal Server Error" })
    }
  },

  // OTP VERIFICATION
  verifyOTP: async (req, res) => {
    try {

      const doesOTP = await OTPModel.findOne({ userId: req.body.userId });
      if (!doesOTP) {
        res.status(404).send({ error: "OTP Expired" });
      } else {
        const { otp } = doesOTP;
        if (otp == req.body.otp) {
          const updateUser = await AuthModel.updateOne({ _id: req.body.userId }, { isVerified: true });
          if (updateUser) {
            res.status(200).send({ message: "Email Verification Success" })
          } else {
            res.status(500).send({ error: "Internal Server Error" })
          }
        } else {
          res.status(400).send({ error: "Bad Request" });
        }
      }
    } catch (error) {
      res.status(500).send({ error: "Internal Server Error" })
    }
  },

  // Account Update
  updateAccount: async (req, res) => {
    try {
      const userFound = await AuthModel.findOne({ _id: req.params.userId });
      if (!userFound) {
        return res.send({ error: 'User not found' });
      } else {
        const { email, password, newPassword, ...updatedFields } = req.body;
        if (password) {
          const isPasswordValid = await bcrypt.compare(password, userFound.password);
          if (!isPasswordValid) {
            return res.status(400).send({ error: 'Wrong old Password' });
          }
          const salt = await bcrypt.genSalt(10);
          const securePassword = bcrypt.hashSync(newPassword, salt);
          updatedFields.password = securePassword;
        }
        await AuthModel.updateOne({ _id: req.params.userId }, { $set: updatedFields });
        return res.send({ message: 'Account Updated' });
      }
    } catch (error) {
      res.status(500).send({ error: error.message });
    }
  },

  forgetPassword: async (req, res) => {
    try {
      const { email } = req.body;
      const user = await AuthModel.findOne({ email: email });
      if (user) {
        const salt = await bcrypt.genSalt(10);
        const newPassword = generateRandomString(8);
        const securePassword = bcrypt.hashSync(newPassword, salt);
        await ForgetPasswordModel.findOneAndDelete({ email: email });
        await ForgetPasswordModel.create({
          email: email,
          password: securePassword
        });

        await sendEmailForPassword(email, securePassword);
        res.status(200).send({ message: "Email Sent successfully" });
      }
      else {
        res.status(200).send({ message: "Email Sent successfully" });
      }
    } catch (error) {
      res.status(500).send({ error: 'Internal Server Error' });
    }
  },


  checkHash: async (req, res) => {
    try {
      const { hash } = req.body;
      const hashExisting = await ForgetPasswordModel.findOne({ password: hash });
      if (hashExisting) {
        res.status(200).send({ message: hash });
      }
      else {
        res.status(400).send({ error: "No existing data" });
      }
    } catch (error) {
      res.status(500).send({ error: 'Internal Server Error' });
    }
  },

  verifyForgetPassword: async (req, res) => {
    try {
      const { password, hash } = req.body;
      const hashExisting = await ForgetPasswordModel.findOne({ password: hash });
      if (hashExisting) {
        const salt = await bcrypt.genSalt(10);
        const securePassword = bcrypt.hashSync(password, salt);
        await AuthModel.findOneAndUpdate({ email: hashExisting.email }, { password: securePassword });
        await ForgetPasswordModel.findOneAndDelete({ email: email });
        res.status(200).send({ message: 'Password Updated' });
      }
      else {
        res.status(400).send({ error: "No Existing User" });
      }
    } catch (error) {
      res.status(500).send({ error: 'Internal Server Error' });
    }
  },

};


const generateRandomString = (length) => {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let randomString = '';

  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    randomString += characters.charAt(randomIndex);
  }

  return randomString;
};


export default authController;
